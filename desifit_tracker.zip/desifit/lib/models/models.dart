class UserProfile {
  final double heightCm, weightKg, targetKg;
  final int age;
  final String gender; // 'male' | 'female' (needed for BMR)
  final String goal;   // 'Weight Loss' | 'Muscle Recomposition'
  UserProfile({required this.heightCm, required this.age, required this.weightKg,
      required this.targetKg, required this.goal, this.gender = 'male'});
  Map<String, dynamic> toMap() => {'heightCm': heightCm, 'age': age, 'weightKg': weightKg,
      'targetKg': targetKg, 'goal': goal, 'gender': gender};
  factory UserProfile.fromMap(Map<String, dynamic> m) => UserProfile(
      heightCm: (m['heightCm'] as num).toDouble(), age: m['age'],
      weightKg: (m['weightKg'] as num).toDouble(), targetKg: (m['targetKg'] as num).toDouble(),
      goal: m['goal'], gender: m['gender'] ?? 'male');
}

class Meal {
  final String name; final double kcal, protein, carbs, fat; final DateTime at;
  Meal(this.name, this.kcal, this.protein, this.carbs, this.fat, this.at);
  Map<String, dynamic> toMap() => {'name': name, 'kcal': kcal, 'protein': protein,
      'carbs': carbs, 'fat': fat, 'at': at.toIso8601String()};
}

class Workout {
  final String type, intensity; final int minutes; final double kcal; final DateTime at;
  Workout(this.type, this.minutes, this.intensity, this.kcal, this.at);
  Map<String, dynamic> toMap() => {'type': type, 'minutes': minutes,
      'intensity': intensity, 'kcal': kcal, 'at': at.toIso8601String()};
}

class HealthSummary {
  final int steps; final double activeKcal; final double sleepHours; final bool synced;
  const HealthSummary({this.steps = 0, this.activeKcal = 0, this.sleepHours = 0, this.synced = false});
  Map<String, dynamic> toMap() => {'steps': steps, 'activeKcal': activeKcal,
      'sleepHours': sleepHours, 'synced': synced};
}
