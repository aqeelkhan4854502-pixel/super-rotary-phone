import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/db_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}
class _ReportsScreenState extends State<ReportsScreen> with SingleTickerProviderStateMixin {
  late final tab = TabController(length: 2, vsync: this);
  final db = DbService();
  List<Map<String, dynamic>> week = [], month = [];
  UserProfile? p;

  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    final now = DateTime.now();
    p = await db.getProfile();
    week = await db.range(now.subtract(const Duration(days: 6)), now);
    month = await db.range(now.subtract(const Duration(days: 29)), now);
    if (mounted) setState(() {});
  }
  double sum(List<Map<String, dynamic>> l, String k) => l.fold(0.0, (s, d) => s + ((d[k] ?? 0) as num));

  Widget weekly() {
    final eaten = sum(week, 'consumed'), burned = sum(week, 'burned'), net = eaten - burned;
    final wts = week.where((d) => d['weightKg'] != null).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(title: const Text('Consumed'), trailing: Text('${eaten.round()} kcal'))),
      Card(child: ListTile(title: const Text('Burned'), trailing: Text('${burned.round()} kcal'))),
      Card(color: net > 0 ? Colors.red.shade50 : Colors.green.shade50,
          child: ListTile(title: Text(net > 0 ? 'Net surplus' : 'Net deficit'), trailing: Text('${net.abs().round()} kcal'))),
      if (wts.length >= 2) Card(child: ListTile(title: const Text('Weight trend'),
          trailing: Text('${((wts.last['weightKg'] as num) - (wts.first['weightKg'] as num)).toStringAsFixed(1)} kg'))),
      SizedBox(height: 220, child: BarChart(BarChartData(
        barGroups: [for (var i = 0; i < week.length; i++) BarChartGroupData(x: i, barRods: [
          BarChartRodData(toY: ((week[i]['consumed'] ?? 0) as num).toDouble(), color: Colors.orange, width: 8),
          BarChartRodData(toY: ((week[i]['burned'] ?? 0) as num).toDouble(), color: Colors.teal, width: 8)])],
        titlesData: const FlTitlesData(topTitles: AxisTitles(), rightTitles: AxisTitles())))),
    ]);
  }

  Widget monthly() {
    final pts = <FlSpot>[];
    for (var i = 0; i < month.length; i++) {
      if (month[i]['weightKg'] != null) pts.add(FlSpot(i.toDouble(), (month[i]['weightKg'] as num).toDouble()));
    }
    final target = p?.targetKg ?? 0;
    return Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      Text('Weight vs target (${target.toStringAsFixed(0)} kg)', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 16),
      SizedBox(height: 280, child: LineChart(LineChartData(
        extraLinesData: ExtraLinesData(horizontalLines: [HorizontalLine(y: target, color: Colors.green, dashArray: [6, 4])]),
        lineBarsData: [LineChartBarData(spots: pts, isCurved: true, color: Colors.orange, barWidth: 3)],
        titlesData: const FlTitlesData(topTitles: AxisTitles(), rightTitles: AxisTitles())))),
    ]));
  }

  @override
  Widget build(BuildContext c) => Column(children: [
        TabBar(controller: tab, tabs: const [Tab(text: 'Weekly'), Tab(text: 'Monthly')]),
        Expanded(child: TabBarView(controller: tab, children: [weekly(), monthly()])),
      ]);
}
