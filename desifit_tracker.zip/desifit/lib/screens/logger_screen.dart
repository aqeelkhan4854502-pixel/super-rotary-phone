import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/models.dart';
import '../services/calc_service.dart';
import '../services/db_service.dart';
import '../services/food_ai_service.dart';

class LoggerScreen extends StatefulWidget {
  const LoggerScreen({super.key});
  @override
  State<LoggerScreen> createState() => _LoggerScreenState();
}
class _LoggerScreenState extends State<LoggerScreen> {
  final db = DbService();
  final type = TextEditingController(), mins = TextEditingController();
  String intensity = 'Medium';
  List<Meal> detected = [];
  bool busy = false;

  Future<void> snap(ImageSource src) async {
    final x = await ImagePicker().pickImage(source: src, maxWidth: 1024, imageQuality: 80);
    if (x == null) return;
    setState(() => busy = true);
    try {
      final token = await FirebaseAuth.instance.currentUser!.getIdToken();
      detected = await FoodAiService().analyze(File(x.path), token!);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not analyse photo. Try again.')));
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> confirmMeals() async {
    for (final m in detected) { await db.addMeal(m); }
    setState(() => detected = []);
  }

  Future<void> saveWorkout() async {
    final p = (await db.getProfile())!;
    final m = int.parse(mins.text);
    await db.addWorkout(Workout(type.text, m, intensity, CalcService.workoutKcal(p.weightKg, m, intensity), DateTime.now()));
    type.clear(); mins.clear();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Workout saved')));
  }

  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
        Text('AI Food Snap 📸', style: Theme.of(c).textTheme.titleLarge),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: () => snap(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('Camera'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(onPressed: () => snap(ImageSource.gallery), icon: const Icon(Icons.photo), label: const Text('Gallery'))),
        ]),
        if (busy) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
        ...detected.map((m) => ListTile(title: Text(m.name),
            subtitle: Text('${m.kcal.round()} kcal • P ${m.protein.round()} • C ${m.carbs.round()} • F ${m.fat.round()}'))),
        if (detected.isNotEmpty) FilledButton(onPressed: confirmMeals, child: const Text('Add to today')),
        const Divider(height: 32),
        Text('Log workout 🏋️', style: Theme.of(c).textTheme.titleLarge),
        const SizedBox(height: 8),
        TextField(controller: type, decoration: const InputDecoration(labelText: 'Exercise (e.g. Running, Gym)', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: mins, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Duration (min)', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'Low', label: Text('Low')), ButtonSegment(value: 'Medium', label: Text('Medium')), ButtonSegment(value: 'High', label: Text('High'))],
            selected: {intensity}, onSelectionChanged: (s) => setState(() => intensity = s.first)),
        const SizedBox(height: 10),
        FilledButton(onPressed: saveWorkout, child: const Text('Save workout')),
      ]);
}
