import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/calc_service.dart';
import '../services/db_service.dart';
import '../services/health_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}
class _DashboardScreenState extends State<DashboardScreen> {
  final db = DbService(), hs = HealthService();
  UserProfile? profile;
  HealthSummary health = const HealthSummary();
  bool loading = true;

  @override
  void initState() { super.initState(); sync(); }

  Future<void> persist() async {
    final d = (await db.day(DateTime.now()).get()).data() ?? {};
    final bmr = CalcService.bmr(profile!);
    final burned = bmr + CalcService.activeFromBand(health) + ((d['workoutKcal'] ?? 0) as num).toDouble();
    await db.saveHealth(DateTime.now(), health, bmr, burned, ((d['consumed'] ?? 0) as num).toDouble());
  }

  Future<void> sync() async {
    setState(() => loading = true);
    profile ??= await db.getProfile();
    await hs.init();
    health = await hs.fetchToday();
    await persist();
    if (mounted) setState(() => loading = false);
  }

  Future<void> manualEntry() async {
    final s = TextEditingController(), k = TextEditingController(), z = TextEditingController();
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Manual entry'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: s, decoration: const InputDecoration(labelText: 'Steps'), keyboardType: TextInputType.number),
        TextField(controller: k, decoration: const InputDecoration(labelText: 'Active kcal'), keyboardType: TextInputType.number),
        TextField(controller: z, decoration: const InputDecoration(labelText: 'Sleep (hours)'), keyboardType: TextInputType.number),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Save'))]));
    health = HealthSummary(steps: int.tryParse(s.text) ?? 0, activeKcal: double.tryParse(k.text) ?? 0,
        sleepHours: double.tryParse(z.text) ?? 0, synced: false);
    await persist();
    if (mounted) setState(() {});
  }

  Widget tile(IconData i, String v, String l) => Expanded(child: Card(child: Padding(
      padding: const EdgeInsets.all(12), child: Column(children: [Icon(i),
        Text(v, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(l, style: const TextStyle(fontSize: 12))]))));

  @override
  Widget build(BuildContext c) {
    if (loading || profile == null) return const Center(child: CircularProgressIndicator());
    return StreamBuilder(
      stream: db.day(DateTime.now()).snapshots(),
      builder: (_, s) {
        final d = s.data?.data() ?? {};
        num n(String k) => (d[k] ?? 0) as num;
        final consumed = n('consumed').toDouble();
        final burned = (d['burned'] ?? CalcService.bmr(profile!)).toDouble();
        final net = CalcService.net(consumed, burned);
        return RefreshIndicator(onRefresh: sync, child: ListView(padding: const EdgeInsets.all(16), children: [
          Text('Today', style: Theme.of(c).textTheme.headlineSmall),
          Card(color: net > 0 ? Colors.red.shade50 : Colors.green.shade50, child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
            Text('${net.abs().round()} kcal', style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold)),
            Text(net > 0 ? 'Surplus' : 'Deficit'),
            Text('Eaten ${consumed.round()}  •  Burned ${burned.round()}')]))),
          Row(children: [tile(Icons.directions_walk, '${health.steps}', 'Steps'),
            tile(Icons.local_fire_department, '${health.activeKcal.round()}', 'Active kcal'),
            tile(Icons.bedtime, health.sleepHours.toStringAsFixed(1), 'Sleep h')]),
          Row(children: [tile(Icons.egg, '${n('protein').round()}g', 'Protein'),
            tile(Icons.rice_bowl, '${n('carbs').round()}g', 'Carbs'),
            tile(Icons.opacity, '${n('fat').round()}g', 'Fat')]),
          if (!health.synced) Card(color: Colors.amber.shade100, child: ListTile(
            leading: const Icon(Icons.watch_off),
            title: const Text('Mi Band data not synced'),
            subtitle: const Text('Open Mi Fitness once, then pull to refresh — or enter manually.'),
            trailing: TextButton(onPressed: manualEntry, child: const Text('Enter'))))
        ]));
      });
  }
}
