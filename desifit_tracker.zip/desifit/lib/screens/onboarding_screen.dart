import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/db_service.dart';
import '../main.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}
class _OnboardingScreenState extends State<OnboardingScreen> {
  final h = TextEditingController(), a = TextEditingController(),
        w = TextEditingController(), t = TextEditingController();
  String goal = 'Weight Loss', gender = 'male';

  Widget field(String label, TextEditingController c, String suffix) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TextField(controller: c, keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: label, suffixText: suffix, border: const OutlineInputBorder())));

  Future<void> submit() async {
    final p = UserProfile(heightCm: double.parse(h.text), age: int.parse(a.text),
        weightKg: double.parse(w.text), targetKg: double.parse(t.text), goal: goal, gender: gender);
    await DbService().saveProfile(p);
    if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeShell()));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
          const SizedBox(height: 12),
          Text('Welcome to DesiFit 💪', style: Theme.of(c).textTheme.headlineMedium),
          const Text('Tell us about you to personalise your plan.'),
          const SizedBox(height: 20),
          field('Height', h, 'cm'), field('Age', a, 'yrs'),
          field('Current weight', w, 'kg'), field('Target weight', t, 'kg'),
          SegmentedButton<String>(segments: const [
            ButtonSegment(value: 'male', label: Text('Male')),
            ButtonSegment(value: 'female', label: Text('Female'))],
            selected: {gender}, onSelectionChanged: (s) => setState(() => gender = s.first)),
          const SizedBox(height: 14),
          const Text('Fitness goal'),
          SegmentedButton<String>(segments: const [
            ButtonSegment(value: 'Weight Loss', label: Text('Weight Loss')),
            ButtonSegment(value: 'Muscle Recomposition', label: Text('Recomp'))],
            selected: {goal}, onSelectionChanged: (s) => setState(() => goal = s.first)),
          const SizedBox(height: 24),
          FilledButton(onPressed: submit, child: const Padding(padding: EdgeInsets.all(14), child: Text('Get started'))),
        ])),
      );
}
