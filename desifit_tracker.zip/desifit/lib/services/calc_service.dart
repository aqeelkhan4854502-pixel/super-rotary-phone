import '../models/models.dart';

class CalcService {
  /// Mifflin-St Jeor BMR (kcal/day)
  static double bmr(UserProfile p) {
    final base = 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age;
    return p.gender == 'female' ? base - 161 : base + 5;
  }

  /// Active burn: band's active kcal if available, else steps estimate.
  static double activeFromBand(HealthSummary h) =>
      h.activeKcal > 0 ? h.activeKcal : h.steps * 0.04;

  /// Total burned = BMR + active (band/steps) + manual workouts.
  /// NOTE: if the band already records a logged workout, avoid double counting.
  static double totalBurned(UserProfile p, HealthSummary h, List<Workout> ws) =>
      bmr(p) + activeFromBand(h) + ws.fold(0.0, (s, w) => s + w.kcal);

  static double net(double consumed, double burned) => consumed - burned; // + surplus, - deficit

  static double targetKcal(UserProfile p, double tdee) =>
      p.goal == 'Weight Loss' ? tdee - 500 : tdee - 250;

  /// MET-based workout estimate
  static double workoutKcal(double weightKg, int min, String intensity) {
    final met = {'Low': 3.5, 'Medium': 6.0, 'High': 9.0}[intensity] ?? 6.0;
    return met * 3.5 * weightKg / 200 * min;
  }
}
