import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/models.dart';

/// Calls YOUR backend proxy (Cloud Function in /functions) so the Vision LLM
/// API key never ships inside the app.
class FoodAiService {
  static const endpoint = 'https://YOUR-REGION-YOUR-PROJECT.cloudfunctions.net/analyzeFood';

  Future<List<Meal>> analyze(File image, String idToken) async {
    final res = await http.post(Uri.parse(endpoint),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $idToken'},
        body: jsonEncode({'imageBase64': base64Encode(await image.readAsBytes()),
                          'mediaType': 'image/jpeg'}));
    if (res.statusCode != 200) throw Exception('Food analysis failed');
    final items = (jsonDecode(res.body)['items'] as List);
    return items.map((i) => Meal(i['name'], (i['kcal'] as num).toDouble(),
        (i['protein'] as num).toDouble(), (i['carbs'] as num).toDouble(),
        (i['fat'] as num).toDouble(), DateTime.now())).toList();
  }
}
