import 'package:health/health.dart';
import '../models/models.dart';

/// Mi Band 10 -> Mi Fitness app -> Health Connect -> this app.
class HealthService {
  final Health _h = Health();
  static const _types = [
    HealthDataType.STEPS,
    HealthDataType.ACTIVE_ENERGY_BURNED,
    HealthDataType.SLEEP_SESSION,
  ];

  Future<bool> init() async {
    try {
      await _h.configure();
      final status = await _h.getHealthConnectSdkStatus();
      if (status != HealthConnectSdkStatus.sdkAvailable) {
        await _h.installHealthConnect();
        return false;
      }
      return await _h.requestAuthorization(_types,
          permissions: _types.map((_) => HealthDataAccess.READ).toList());
    } catch (_) { return false; }
  }

  /// Returns synced:false on any failure so the UI can offer manual entry.
  Future<HealthSummary> fetchToday() async {
    try {
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day);
      final steps = await _h.getTotalStepsInInterval(start, now) ?? 0;
      final data = await _h.getHealthDataFromTypes(
          startTime: start.subtract(const Duration(hours: 6)), // last night's sleep
          endTime: now,
          types: [HealthDataType.ACTIVE_ENERGY_BURNED, HealthDataType.SLEEP_SESSION]);
      double kcal = 0, sleepMin = 0;
      for (final d in _h.removeDuplicates(data)) {
        final v = (d.value as NumericHealthValue).numericValue.toDouble();
        if (d.type == HealthDataType.ACTIVE_ENERGY_BURNED) kcal += v;
        if (d.type == HealthDataType.SLEEP_SESSION) sleepMin += v; // minutes
      }
      final ok = steps > 0 || kcal > 0 || sleepMin > 0;
      return HealthSummary(steps: steps, activeKcal: kcal, sleepHours: sleepMin / 60, synced: ok);
    } catch (_) {
      return const HealthSummary(synced: false);
    }
  }
}
