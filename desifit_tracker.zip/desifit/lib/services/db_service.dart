import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';

class DbService {
  final _db = FirebaseFirestore.instance;
  String get uid => FirebaseAuth.instance.currentUser!.uid;
  DocumentReference<Map<String, dynamic>> get _user => _db.collection('users').doc(uid);
  static String key(DateTime d) => DateFormat('yyyy-MM-dd').format(d);
  DocumentReference<Map<String, dynamic>> day(DateTime d) => _user.collection('days').doc(key(d));

  Future<void> saveProfile(UserProfile p) async {
    await _user.set({'profile': p.toMap(), 'createdAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
    await logWeight(DateTime.now(), p.weightKg);
  }
  Future<UserProfile?> getProfile() async {
    final m = (await _user.get()).data()?['profile'];
    return m == null ? null : UserProfile.fromMap(Map<String, dynamic>.from(m));
  }

  Future<void> addMeal(Meal m) async {
    await day(m.at).collection('meals').add(m.toMap());
    await day(m.at).set({'consumed': FieldValue.increment(m.kcal), 'protein': FieldValue.increment(m.protein),
      'carbs': FieldValue.increment(m.carbs), 'fat': FieldValue.increment(m.fat)}, SetOptions(merge: true));
  }
  Future<void> addWorkout(Workout w) async {
    await day(w.at).collection('workouts').add(w.toMap());
    await day(w.at).set({'workoutKcal': FieldValue.increment(w.kcal)}, SetOptions(merge: true));
  }
  Future<void> saveHealth(DateTime d, HealthSummary h, double bmr, double burned, double consumed) =>
      day(d).set({'health': h.toMap(), 'bmr': bmr, 'burned': burned, 'net': consumed - burned}, SetOptions(merge: true));

  Future<void> logWeight(DateTime d, double kg) =>
      day(d).set({'weightKg': kg}, SetOptions(merge: true));

  /// Daily docs between two dates (weekly/monthly reports)
  Future<List<Map<String, dynamic>>> range(DateTime from, DateTime to) async {
    final q = await _user.collection('days')
        .where(FieldPath.documentId, isGreaterThanOrEqualTo: key(from))
        .where(FieldPath.documentId, isLessThanOrEqualTo: key(to)).get();
    final l = q.docs.map((d) => {'date': d.id, ...d.data()}).toList();
    l.sort((a, b) => (a['date'] as String).compareTo(b['date'] as String));
    return l;
  }
}
