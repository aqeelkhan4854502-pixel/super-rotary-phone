import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'services/db_service.dart';
import 'screens/onboarding_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/logger_screen.dart';
import 'screens/reports_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  if (FirebaseAuth.instance.currentUser == null) await FirebaseAuth.instance.signInAnonymously();
  runApp(const DesiFitApp());
}

class DesiFitApp extends StatelessWidget {
  const DesiFitApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'DesiFit Tracker',
        theme: ThemeData(colorSchemeSeed: const Color(0xFFFF7A1A), useMaterial3: true),
        home: FutureBuilder(
          future: DbService().getProfile(),
          builder: (_, s) {
            if (s.connectionState != ConnectionState.done) return const Scaffold(body: Center(child: CircularProgressIndicator()));
            return s.data == null ? const OnboardingScreen() : const HomeShell();
          },
        ),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int i = 0;
  final pages = const [DashboardScreen(), LoggerScreen(), ReportsScreen()];
  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(child: pages[i]),
        bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (v) => setState(() => i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard), label: 'Today'),
            NavigationDestination(icon: Icon(Icons.add_circle), label: 'Log'),
            NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Reports'),
          ]),
      );
}
