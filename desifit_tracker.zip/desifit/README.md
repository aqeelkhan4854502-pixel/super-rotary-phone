# DesiFit Tracker — Flutter + Firebase

## Architecture
Mi Band 10 → Mi Fitness app → Health Connect → HealthService (`health` pkg)
UI (Onboarding / Today / Log / Reports) → CalcService (BMR, net) → DbService → Firestore
FoodAiService → Cloud Function (holds API key) → Vision LLM

## Firestore schema
users/{uid}
  profile: {heightCm, age, gender, weightKg, targetKg, goal}
  days/{yyyy-MM-dd}
    consumed, protein, carbs, fat, workoutKcal, bmr, burned, net, weightKg
    health: {steps, activeKcal, sleepHours, synced}
    meals/{id}: {name, kcal, protein, carbs, fat, at}
    workouts/{id}: {type, minutes, intensity, kcal, at}

Rules: match /users/{uid}/{document=**} { allow read, write: if request.auth.uid == uid; }

## Mi Band 10 connection steps
1. Mi Fitness has no public API and Google Fit APIs are being retired, so use Health Connect.
2. Android 14+ has Health Connect built in; otherwise install from Play Store.
3. Pair Mi Band 10 in the Mi Fitness app.
4. In Mi Fitness settings, enable Health Connect sync (menu names vary by version/region; verify on your phone). Not every metric may be written, hence the manual fallback.
5. In Health Connect > App permissions, confirm Mi Fitness can write steps, sleep, calories.
6. Add manifest snippet (android_snippets/), minSdkVersion 26, MainActivity extends FlutterFragmentActivity.
7. App runs HealthService.init() then fetchToday() on open and pull-to-refresh.
8. Failure/empty data → synced:false → manual entry card.
9. Later: workmanager periodic background sync.

## Setup
flutter create . ; flutterfire configure ; firebase functions:secrets:set ANTHROPIC_API_KEY ; deploy functions ; set endpoint in food_ai_service.dart.
