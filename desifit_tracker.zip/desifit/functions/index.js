// Firebase Cloud Function: verifies the user, calls a Vision LLM, returns JSON macros.
const { onRequest } = require('firebase-functions/v2/https');
const admin = require('firebase-admin'); admin.initializeApp();

const PROMPT = `You are a nutrition estimator for Indian home food (roti, dal, sabzi, rice, eggs, fruits).
Identify each food item, estimate portion size, and return ONLY JSON:
{"items":[{"name":"2 rotis","kcal":240,"protein":8,"carbs":46,"fat":3}]}
Values are estimates for the visible portion.`;

exports.analyzeFood = onRequest({ secrets: ['ANTHROPIC_API_KEY'] }, async (req, res) => {
  try {
    await admin.auth().verifyIdToken((req.headers.authorization || '').replace('Bearer ', ''));
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01',
                 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 800, messages: [{ role: 'user',
        content: [{ type: 'image', source: { type: 'base64', media_type: req.body.mediaType, data: req.body.imageBase64 } },
                  { type: 'text', text: PROMPT }] }] })
    });
    const j = await r.json();
    const text = j.content.map(c => c.text || '').join('').replace(/```json|```/g, '').trim();
    res.json(JSON.parse(text));
  } catch (e) { res.status(500).json({ error: String(e) }); }
});
